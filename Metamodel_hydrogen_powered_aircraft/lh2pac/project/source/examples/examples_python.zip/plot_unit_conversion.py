"""
Unit conversion
===============

"""
from marilib.utils import unit

min = 1
s = unit.s_min(min)

print(s)