r"""
ex design
============

some comment

"""
from project.source._results.design_space import L2PACDesignSpace

design_space = L2PACDesignSpace()
print(design_space)