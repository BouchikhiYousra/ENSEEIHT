from .turbofan_h2_function import (
    str_h2turbofan as print_model,
    fct_turbofan_h2 as evaluate_model,
)
